import "./App.css";
import Cards from "./Mapping/Cards";
// import About from "./Component/About";
// import Contact from "./Component/Contact";
// import Home from "./Component/Home";
// import Portfolio from "./Component/Portfolio";
function App() {
  return (
    <>
      {/* <div className="main">
        <Home />
        <About />
      </div>
      <div className="main">
        <Contact/>
        <Portfolio />
      </div> */}
      <Cards/>
    </>
  );
}

export default App;
