import React from 'react'

export default function Home() {
  return (
    <>
      <div className="card">
       <h1>Home Page</h1>
       <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Voluptatum mollitia fuga eligendi. Repellendus dolores, quam fugiat magnam ab hic veritatis dolor expedita officiis accusantium qui sequi illum tempore ut voluptatem?</p>
       <hr />
       <button>Hello</button>
       </div>
    </>
  )
}
